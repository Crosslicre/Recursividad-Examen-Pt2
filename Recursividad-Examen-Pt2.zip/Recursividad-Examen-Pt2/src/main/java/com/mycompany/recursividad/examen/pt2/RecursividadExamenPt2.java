package com.mycompany.recursividad.examen.pt2;

import java.util.Arrays;

public class RecursividadExamenPt2 {
    
        public static void main(String[] args)
    {
        int ArrayNumeros[] = {3, 5, 12, 6, 90, 22, 30, 15, 74, 49};
        
        Recursividad(ArrayNumeros, ArrayNumeros.length);

        System.out.println("Números Ordenados de menor a mayor: ");
        System.out.println(Arrays.toString(ArrayNumeros));
    }
   

    static void Recursividad(int ArrayNumeros[], int valores)
    {
        if (valores == 1)
            return;

        for (int i=0; i<valores-1; i++)
            if (ArrayNumeros[i] > ArrayNumeros[i+1])
            {
                int Orden = ArrayNumeros[i];
                ArrayNumeros[i] = ArrayNumeros[i+1];
                ArrayNumeros[i+1] = Orden;
            }

        Recursividad(ArrayNumeros, valores-1);
    }
}